<script setup>
import Liste from './Liste.vue'
import Details from './Details.vue'
import { Candidat } from '@/models/candidat'
import { ref } from 'vue'

let tabCands = [
  new Candidat(1, 'bart', 'simpson', 42, 'trainer', 'bart.jpeg'),
  new Candidat(2, 'homer', 'simpson', 23, 'chef de projet', 'homer.png'),
  new Candidat(3, 'lisa', 'simpson', 27, 'designer', 'lisa.png'),
]

let selectedCand = ref(undefined)

function setSelectedCand(cand) {
  selectedCand.value = cand
  // console.log(selectedCand.value)
}
</script>
<template>
  <div class="row">
    <div class="col-5">
      <Liste :tab="tabCands" :changeCand="selectedCand" @onUpdatedCand="setSelectedCand"></Liste>
    </div>
    <div class="col-7">
      <Details v-show="selectedCand" :selCand="selectedCand"></Details>
    </div>
  </div>
</template>
