<script setup>
defineProps(['oneCandidate','updateCand'])
let emit = defineEmits(['onSelectedCand'])

</script>
<template>
  <li @click="emit('onSelectedCand', oneCandidate)" class="list-group-item">
  <img :src="oneCandidate.avatar"></img>
  {{ oneCandidate.prenom }} {{  oneCandidate.prenom }}
  </li>
</template>
<style scoped>
img {
    width: 50px;
    height: 50px;
}</style>
