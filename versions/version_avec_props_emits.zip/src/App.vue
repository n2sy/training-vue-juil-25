<script setup>
import Cv from '../src/project/Cv.vue'
</script>

<template>
  <div class="container">
    <Cv></Cv>
  </div>
</template>

<style scoped></style>
